/*jslint browser: true, nomen: true,  white: true */
/* global jQuery, $ */
jQuery(function($) {
"use strict";


    $(".js-sort-dropdown").select2({
        tags: true,
        placeholder: "Select what you want to share"
    })


});